const { cmd, commands } = require('../command');
const axios = require('axios');

cmd({
  'pattern': "couplepp",
  'alias': ["couple", "cpp"],
  'react': '💑',
  'desc': "Get a male and female couple profile picture.",
  'category': "image",
  'use': ".couplepp",
  'filename': __filename
}, async (conn, m, store, {
  from,
  args,
  reply
}) => {
  try {
    reply("*💑 Fetching couple profile pictures...*");
    
    const response = await axios.get("https://api.deline.web.id/random/ppcouple");

    if (!response.data || !response.data.status) {
      return reply("❌ Failed to fetch couple profile pictures. Please try again later.");
    }

    const malePp = response.data.result.cowo;
    const femalePp = response.data.result.cewe;

    if (malePp) {
      await conn.sendMessage(from, {
        'image': { 'url': malePp },
        'caption': "👨 Male Couple Profile Picture"
      }, { 'quoted': m });
    }

    if (femalePp) {
      await conn.sendMessage(from, {
        'image': { 'url': femalePp },
        'caption': "👩 Female Couple Profile Picture"
      }, { 'quoted': m });
    }

  } catch (error) {
    console.error(error);
    reply("❌ An error occurred while fetching the couple profile pictures.");
  }
});
